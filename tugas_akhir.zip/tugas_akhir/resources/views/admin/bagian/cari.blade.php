<div class="row mb-3">
        <div class="col-md-4">
            <input id="search" type="text" class="form-control" placeholder="Cari Barang...">
        </div>
        <div class="col-md-4">
            <select id="categoryFilter" class="form-control">
                <option value="all">Semua Kategori</option>
                <option value="elektronik">Elektronik</option>
                <option value="fashion">Fashion</option>
                <!-- Tambahkan lebih banyak kategori sesuai kebutuhan -->
            </select>
        </div>
        <div class="col-md-4 text-right">
            <button class="btn btn-success" data-toggle="modal" data-target="#addModal"><i class="fas fa-plus"></i> Tambah Barang</button>
        </div>
    </div>