

<div class="sidebar">
    <nav class="navbar navbar-dark">
        <a class="navbar-brand" href="#">Super Admin</a>
    </nav>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active" href="/admin"><i class="fas fa-box"></i> Barang</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/user"><i class="fas fa-users"></i> User</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/laporan"><i class="fas fa-shopping-cart"></i> Transaksi</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </li>
    </ul>
</div>