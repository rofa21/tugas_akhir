

@include('admin.bagian.sidebarad')
@include('admin.bagian.headerad')


<h1>master</h1>
@yield('content')

