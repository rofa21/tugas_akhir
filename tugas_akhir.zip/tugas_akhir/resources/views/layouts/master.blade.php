@include('bagian.header')

@include('bagian.navbar')


<h1>master</h1>
@yield('container')

@include('bagian.footer')