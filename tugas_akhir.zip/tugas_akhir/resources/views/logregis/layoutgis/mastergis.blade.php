@include('logregis.headergis')

@include('logregis.navgis')


<h1>master</h1>
@yield('contentgis')

@include('logregis.footergis')