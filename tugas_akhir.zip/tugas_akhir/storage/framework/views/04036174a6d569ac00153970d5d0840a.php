<?php echo $__env->make('logregis.headergis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('logregis.navgis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    body{
        background-image: url('/img/2.jpg');
        background-size: 1400px;
    }

    .btn{
        color:black;
        background-color: white;
        font-weight: bold; /* Membuat teks tebal */
    }

    h1{
        font-family: 'Poppins', sans-serif; /* Menggunakan font Poppins */
            font-weight: 700; /* Membuat teks tebal */
            font-size: 2.5em; /* Mengatur ukuran font */
            color:white;
    }
</style>
<body>
<div class="wrapper">
        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h1>Member Login</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="remember-forgot">
                <label><input type="checkbox" name="remember"> Remember me </label>
                <a href="#">Forgot password?</a>
            </div>
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <?php echo e($errors->first()); ?>

                </div>
            <?php endif; ?>

            <button type="submit" class="btn">Sign in</button>

            <div class="register-link">
                <p>Don't have an account? <a href="<?php echo e(route('register.form')); ?>">Sign Up Here!</a></p>
            </div>
        </form>
    </div>
</body>
</html>

<?php echo $__env->yieldContent('contentgis'); ?>

<?php echo $__env->make('logregis.footergis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/welcome.blade.php ENDPATH**/ ?>