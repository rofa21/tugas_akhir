

<?php $__env->startSection('container'); ?>

<div class="container mt-5">
    <h2>Transaksi</h2>
    <form id="transaksiForm" action="<?php echo e(route('transaksi.selesai')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mb-4 barang-item" data-harga="<?php echo e($barang->harga); ?>">
            <div class="col-md-4">
                <img src="<?php echo e(asset('storage/' . $barang->gambar)); ?>" alt="Product Image" class="product-image" height="300px" width="300px">
            </div>
            <div class="col-md-5">
                <h5>Nama Barang: <?php echo e($barang->nama); ?></h5>
                <p>Merek: <?php echo e($barang->merek); ?></p>
                <p>Harga: RP. <?php echo e(number_format($barang->harga, 0, ',', '.')); ?></p>
                <p>Warna: <?php echo e($barang->warna ?? 'N/A'); ?></p>
                <p>Ukuran: <?php echo e($barang->ukuran ?? 'N/A'); ?></p>
            </div>
            <div class="form-group col-md-2">
                <label for="jumlah_<?php echo e($barang->id); ?>">Jumlah:</label>
                <input type="number" class="form-control jumlah" id="jumlah_<?php echo e($barang->id); ?>" name="jumlah[<?php echo e($barang->id); ?>]" value="1" min="1" data-harga="<?php echo e($barang->harga); ?>">
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="form-group">
            <label for="alamat">Alamat Pengiriman:</label>
            <textarea class="form-control" id="alamat" name="alamat" required></textarea>
        </div>

        <div class="form-group">
            <label for="metodePembayaran">Metode Pembayaran:</label>
            <select class="form-control" id="metodePembayaran" name="metode_pembayaran" required>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="credit_card">Credit Card</option>
                <option value="paypal">PayPal</option>
            </select>
        </div>

        <div class="form-group">
            <label for="pengiriman">Metode Pengiriman:</label>
            <select class="form-control" id="pengiriman" name="metode_pengiriman" required>
                <option value="12000">JNE</option>
                <option value="13000">POS</option>
                <option value="10000">TIKI</option>
            </select>
        </div>

        <div class="form-group">
            <label for="total">Total:</label>
            <input type="text" class="form-control" id="total" name="total" readonly>
        </div>

        <button type="submit" class="btn btn-success">Selesai</button>
        <a class="btn btn-primary" href="/keranjang" role="button">Kembali</a>
    </form>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/transaksi.blade.php ENDPATH**/ ?>