<?php echo $__env->make('bagian.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('bagian.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <h4>Produk Unggulan</h4>
    
    <!-- Carousel Container -->
    <div class="carousel-container mt-0 mb-3">
        <div class="carousel">
            <img src="img/adidas.jpg" alt="Image 1" class="carousel-image">
            <img src="img/futsal1.jpg" alt="Image 2" class="carousel-image">
            <img src="img/sports.jpg" alt="Image 3" class="carousel-image">
        </div>
    </div>
    
    
    <h4>List Barang</h4>

    <div class="row1">
        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(url('storage/'.$barang->gambar)); ?>"  class="card-img-top" alt="<?php echo e($barang->nama); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($barang->nama); ?></h5>
                        <p class="card-text"><?php echo e($barang->merek); ?></p>
                       
                        <p class="card-text">Harga: RP. <?php echo e($barang->harga); ?></p>
                        <a href="<?php echo e(route('barang.show', $barang->id)); ?>" class="btn btn-primary">Detail</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
<?php echo $__env->yieldContent('container'); ?>

<?php echo $__env->make('bagian.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/home.blade.php ENDPATH**/ ?>