

<?php $__env->startSection('container'); ?>

<div class="container mt-5">
    <h2 class="mb-4">Keranjang Belanja</h2>
    
    <!-- Header -->
    <div class="cart-header">
        <div>
            <input type="checkbox" id="select-all">
            <label for="select-all">Pilih Semua</label>
        </div>
        <button class="btn btn-danger btn-sm" id="remove-selected">Hapus</button>
    </div>

    <!-- Cart Items -->
    <form action="<?php echo e(route('keranjang.purchase')); ?>" method="POST" id="cart-form">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="cart-item">
        <div class="item-header">
            <input type="checkbox" name="selected_items[]" class="select-item" value="<?php echo e($item['id']); ?>" data-id="<?php echo e($item['id']); ?>">
            <img src="<?php echo e(asset('storage/' . $item['gambar'])); ?>" alt="<?php echo e($item['nama']); ?>" class="item-image">
        </div>
        <div class="product-details">
            <span class="product-name"><?php echo e($item['nama']); ?></span>
            <span class="product-brand">Merek: <?php echo e($item['merek']); ?></span>
            <span class="product-size">Ukuran: <?php echo e($item['ukuran']); ?></span>
            <span class="product-color">Warna: <?php echo e($item['warna'] ?? 'N/A'); ?></span>
            <span class="product-price">Rp. <?php echo e(number_format($item['harga'], 0, ',', '.')); ?></span>
            <div class="product-button">
            <button class="btn btn-danger btn-sm remove-button " data-id="<?php echo e($item['id']); ?>">Hapus</button>
             </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Footer -->
    <div class="cart-footer">
        <div>
            <input type="checkbox" id="select-all-footer">
            <label for="select-all-footer">Pilih Semua</label>
        </div>
        <button type="submit" class="btn btn-success">Beli</button>
    </div>
</form>


    <!-- Summary -->
    <div class="summary">
        <h3>Ringkasan Belanja</h3>
        <div class="total">
            <span>Total Beli:</span>
            <span>Rp. <?php echo e(number_format(collect($items)->sum('harga'), 0, ',', '.')); ?></span>
        </div>
        <a class="btn btn-primary" href="/home" role="button">Kembali</a>

    </div>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/keranjang.blade.php ENDPATH**/ ?>