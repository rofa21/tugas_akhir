<?php echo $__env->make('bagian.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('bagian.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h1>master</h1>
<?php echo $__env->yieldContent('container'); ?>

<?php echo $__env->make('bagian.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/layouts/master.blade.php ENDPATH**/ ?>