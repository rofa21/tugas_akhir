<?php $__env->startSection('contentgis'); ?>
    

<style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap");


body{
	
	
    background-image: url('/img/2.jpg');
        background-size: 1400px;
}


</style>


   
    <div class="form">
        <form action="<?php echo e(route('register')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h1>Registration</h1>

            <div class="input-box">
                <div class="input-field">
                    <input type="text" name="nama" placeholder="Full Name" value="<?php echo e(old('nama')); ?>" required>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-field">
                    <input type="text" name="username" placeholder="Username" value="<?php echo e(old('username')); ?>" required>
                    <i class='bx bxs-user'></i>
                </div>
            </div>

            <div class="input-box">
                <div class="input-field">
                    <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                    <i class='bx bxs-envelope'></i>
                </div>
                <div class="input-field">
                    <input type="text" name="telepon" placeholder="Number" value="<?php echo e(old('telepon')); ?>" required>
                    <i class='bx bxs-phone-call'></i>
                </div>
            </div>

            <div class="input-box">
                <div class="input-field">
                    <input type="password" name="password" placeholder="Password" required>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <div class="input-field">
                    <input type="password" name="password_confirmation" placeholder="Confirm Password" required>
                    <i class='bx bxs-lock-alt'></i>
                </div>
            </div>

            <label>
                <input type="checkbox" required>
                I hereby declare that the above information provided is true and correct
            </label>

            <button type="submit" class="btn">Registration</button>
        </form>
    </div>
  



</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('logregis.layoutgis.mastergis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/register.blade.php ENDPATH**/ ?>