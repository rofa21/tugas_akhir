

<?php echo $__env->make('admin.bagian.sidebarad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.bagian.headerad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h1>master</h1>
<?php echo $__env->yieldContent('content'); ?>

<?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/admin/layout/masterad.blade.php ENDPATH**/ ?>