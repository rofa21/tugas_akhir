<?php echo $__env->make('logregis.headergis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('logregis.navgis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h1>master</h1>
<?php echo $__env->yieldContent('contentgis'); ?>

<?php echo $__env->make('logregis.footergis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/logregis/layoutgis/mastergis.blade.php ENDPATH**/ ?>