

<?php $__env->startSection('content'); ?>
<style>
    .content{
        margin-top: -70px;
    }
</style>
<div class="content">
    <h1>Data Pengguna</h1>
    
    <div class="table-wrapper">
        <table id="usersTable" class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                <th>No</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>No Telepon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->telepon); ?></td>
                    <td>
                    <a class="btn btn-danger ml-3" href="/destroy/<?php echo e($user->id); ?>" role="button" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('js/admin/fresh.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/admin/pelanggan.blade.php ENDPATH**/ ?>