

<?php $__env->startSection('content'); ?>
<div class="content">
    <form id="editForm" action="/transaksi/<?php echo e($transaksi->id_transaksi); ?>"  method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="modal-body">
            <div class="form-group">
                <label for="namaPelanggan">Nama Pelanggan</label>
                <select class="form-control" id="namaPelanggan" name="id_user" required>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e($transaksi->id_user == $user->id ? 'selected' : ''); ?>><?php echo e($user->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="namaBarang">Nama Barang</label>
                <select class="form-control" id="namaBarang" name="id_barang" required>
                   <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($barangl->id); ?>" <?php echo e($transaksi->id_barang == $barangl->id ? 'selected' : ''); ?>><?php echo e($barangl->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="metodePengiriman">Metode Pengiriman</label>
                <select class="form-control" id="metodePengiriman" name="pengiriman" required>
                    <option value="jne" <?php echo e($transaksi->pengiriman == 'jne' ? 'selected' : ''); ?>>JNE</option>
                    <option value="jt" <?php echo e($transaksi->pengiriman == 'jt' ? 'selected' : ''); ?>>J&T</option>
                    <!-- Tambahkan lebih banyak kategori sesuai kebutuhan -->
                </select>
            </div>
            <div class="form-group">
                <label for="metodePembayaran">Metode Pembayaran</label>
                <select class="form-control" id="metodePembayaran" name="metode_pembayaran" required>
                    <option value="cod" <?php echo e($transaksi->metode_pembayaran == 'cod' ? 'selected' : ''); ?>>COD</option>
                    <option value="bri" <?php echo e($transaksi->metode_pembayaran == 'bri' ? 'selected' : ''); ?>>BRI</option>
                    <option value="dana" <?php echo e($transaksi->metode_pembayaran == 'dana' ? 'selected' : ''); ?>>DANA</option>
                    <option value="bni" <?php echo e($transaksi->metode_pembayaran == 'bni' ? 'selected' : ''); ?>>BNI</option>
                    <option value="bca" <?php echo e($transaksi->metode_pembayaran == 'bca' ? 'selected' : ''); ?>>BCA</option>
                    <!-- Tambahkan lebih banyak kategori sesuai kebutuhan -->
                </select>
            </div>
            <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo e($transaksi->tanggal); ?>" required>
            </div>
            <div class="form-group">
                <label for="jumlahBeli">Jumlah Beli</label>
                <input type="number" class="form-control" id="jumlahBeli" name="jumlah" value="<?php echo e($transaksi->jumlah); ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Perbarui</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appsepatu\tugas_akhir\resources\views/admin/transaksi/edit.blade.php ENDPATH**/ ?>